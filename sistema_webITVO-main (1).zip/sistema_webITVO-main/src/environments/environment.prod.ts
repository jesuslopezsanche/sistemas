export const environment = {
  firebase: {
    projectId: 'qr-admin-a1573',
    appId: '1:42737786083:web:b3fdb85c8bc9d38f50b9d6',
    storageBucket: 'qr-admin-a1573.appspot.com',
    apiKey: 'AIzaSyC8EVp98Bt_mwXC_gtJCovC58d_8cYcZRs',
    authDomain: 'qr-admin-a1573.firebaseapp.com',
    messagingSenderId: '42737786083',
    measurementId: 'G-N2X9BRCXMD',
  },
  production: true
};
